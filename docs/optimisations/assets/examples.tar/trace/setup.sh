mount -t debugfs nodev /sys/kernel/debug
